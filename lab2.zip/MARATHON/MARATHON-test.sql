-- Jack Goyette, Spencer Schurk
-- jgoyette@calpoly.edu, sschurk@calpoly.edu

SELECT * FROM MARATHON; -- should print table with all data from marathon.csv
SELECT COUNT(*) FROM MARATHON; -- should display 463 tuples
