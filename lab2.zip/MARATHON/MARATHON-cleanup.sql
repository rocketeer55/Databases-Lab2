-- Jack Goyette, Spencer Schurk
-- jgoyette@calpoly.edu, sschurk@calpoly.edu

DROP TABLE MARATHON;
