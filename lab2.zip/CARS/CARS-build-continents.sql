-- Jack Goyette, Spencer Schurk
-- jgoyette@calpoly.edu, sschurk@calpoly.edu


INSERT INTO CONTINENTS VALUES(1,'america');
INSERT INTO CONTINENTS VALUES(2,'europe');
INSERT INTO CONTINENTS VALUES(3,'asia');
INSERT INTO CONTINENTS VALUES(4,'africa');
INSERT INTO CONTINENTS VALUES(5,'australia');
