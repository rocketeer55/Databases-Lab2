-- Jack Goyette, Spencer Schurk
-- jgoyette@calpoly.edu, sschurk@calpoly.edu

INSERT INTO CARMAKERS VALUES(1,'amc','American Motor Company',1);
INSERT INTO CARMAKERS VALUES(2,'volkswagen','Volkswagen',2);
INSERT INTO CARMAKERS VALUES(3,'bmw','BMW',2);
INSERT INTO CARMAKERS VALUES(4,'gm','General Motors',1);
INSERT INTO CARMAKERS VALUES(5,'ford','Ford Motor Company',1);
INSERT INTO CARMAKERS VALUES(6,'chrysler','Chrysler',1);
INSERT INTO CARMAKERS VALUES(7,'citroen','Citroen',3);
INSERT INTO CARMAKERS VALUES(8,'nissan','Nissan Motors',4);
INSERT INTO CARMAKERS VALUES(9,'fiat','Fiat',5);
INSERT INTO CARMAKERS VALUES(10,'hi','hi',null);
INSERT INTO CARMAKERS VALUES(11,'honda','Honda',4);
INSERT INTO CARMAKERS VALUES(12,'mazda','Mazda',4);
INSERT INTO CARMAKERS VALUES(13,'daimler benz','Daimler Benz',2);
INSERT INTO CARMAKERS VALUES(14,'opel','Opel',2);
INSERT INTO CARMAKERS VALUES(15,'peugeaut','Peugeaut',3);
INSERT INTO CARMAKERS VALUES(16,'renault','Renault',3);
INSERT INTO CARMAKERS VALUES(17,'saab','Saab',6);
INSERT INTO CARMAKERS VALUES(18,'subaru','Subaru',4);
INSERT INTO CARMAKERS VALUES(19,'toyota','Toyota',4);
INSERT INTO CARMAKERS VALUES(20,'triumph','Triumph',7);
INSERT INTO CARMAKERS VALUES(21,'volvo','Volvo',6);
INSERT INTO CARMAKERS VALUES(22,'kia','Kia Motors',8);
INSERT INTO CARMAKERS VALUES(23,'hyundai','Hyundai',8);
